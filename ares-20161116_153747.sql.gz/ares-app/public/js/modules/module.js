var application = {
    'init': function(){

    }
}

jQuery(document).ready(function(){
    application.init();
});