<?php
/**
 * Created by PhpStorm.
 * User: brodriguez
 * Date: 20/09/16
 * Time: 01:26 PM
 */
return array(
    'db' => array(
        'username' => 'root',
        'password' => 'p3lk4x',
    ),
);