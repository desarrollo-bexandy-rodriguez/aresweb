<?php
/**
 * Created by PhpStorm.
 * User: brodriguez
 * Date: 03/10/16
 * Time: 03:49 PM
 */

namespace Almacen\Controller;


use Zend\Mvc\Controller\AbstractActionController;

class MermaController extends AbstractActionController
{

}